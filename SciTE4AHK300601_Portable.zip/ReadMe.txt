SciTE4AutoHotkey v3.0.06.01 Portable Edition
============================================

Thank you for downloading SciTE4AutoHotkey.
Supported platforms: Windows XP SP3+, Vista, 7, 8, 8.1, 10

For the best user experience, use AutoHotkey v1.1+.

Installation: unpack this archive to your AutoHotkey folder so that you have:

AutoHotkey
|_______ AutoHotkey.exe
|_______ AutoHotkey.chm
|_______ SciTE
         |______ etc...

Side-by-side AutoHotkey builds (AutoHotkey32a.exe, 32w.exe, 64w.exe) are also supported.
